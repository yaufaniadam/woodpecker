<?php
/**
 * Plugin Name: MB Admin Columns
 * Plugin URI: https://metabox.io/plugins/mb-admin-columns/
 * Description: Show custom fields in the post list table.
 * Version: 1.0.0
 * Author: Rilwis
 * Author URI: http://www.deluxeblogtips.com
 * License: GPL2+
 * Text Domain: mb-admin-columns
 * Domain Path: /lang/
 */

// Prevent loading this file directly.
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'mb_settings_page_load' ) )
{
	add_action( 'admin_init', 'mb_settings_page_load' );

	/**
	 * Load plugin files after Meta Box is loaded
	 */
	function mb_settings_page_load()
	{
		if ( ! class_exists( 'RW_Meta_Box' ) || class_exists( 'MB_Admin_Columns_Post' ) )
		{
			return;
		}

		require plugin_dir_path( __FILE__ ) . 'inc/post.php';

		$meta_boxes = RWMB_Core::get_meta_boxes();
		foreach ( $meta_boxes as $meta_box )
		{
			$fields = &$meta_box['fields'];
			foreach ( $fields as $k => $field )
			{
				if ( ! isset( $field['admin_columns'] ) )
				{
					unset( $fields[$k] );
				}
			}
			if ( empty( $fields ) )
			{
				continue;
			}

			$meta_box = RW_Meta_Box::normalize( $meta_box );
			foreach ( $meta_box['post_types'] as $post_type )
			{
				new MB_Admin_Columns_Post( $post_type, $fields );
			}
		}
	}
}
